package com.cognizant.springbootreact;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootreactApplicationTests {

	@Test
	void contextLoads() {
	}

}
